<p>If you found this plugin useful, or I've already helped you, please consider buying me a <a href="http://en.wikipedia.org/wiki/Newcastle_Brown_Ale" target="_blank">beer</a> or two.</p>
<p>Donations help alleviate the time spent developing and supporting this plugin and are greatly appreciated.</p>

<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=N9NFVADLVUR7A" target="_blank" id="wphttps-donate-link">
	<img alt="Donate" src="https://www.paypal.com/en_US/i/btn/btn_donate_SM.gif" width="74" height="21" />
</a>