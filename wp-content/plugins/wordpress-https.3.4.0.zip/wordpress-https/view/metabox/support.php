<ul>
	<li>Having problems getting your site secure?</li>
	<li>Please read the introductory <a href="http://wordpress.org/extend/plugins/wordpress-https/installation/" target="_blank">Installation Guide</a>.</li>
	<li>If you haven't already, check out the <a href="http://wordpress.org/extend/plugins/wordpress-https/faq/" target="_blank">Frequently Asked Questions</a>.</li>
</ul>
<p>Still not fixed? Please <a href="http://wordpress.org/support/plugin/wordpress-https" target="_blank">start a support topic</a> and someone from the community may be able to assist you. If you need immediate assistance, I am available for hire. Unfortunately, I do not have time to support the plugin for free.</p>