<?php
/**
 * Base Theme
 *
 * @author Mike Ems
 * @package Mvied
 */
class Mvied_Theme_Base extends Mvied_Base {

}
