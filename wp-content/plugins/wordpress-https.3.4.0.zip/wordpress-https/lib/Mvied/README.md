## Mvied

### About
This library was created by Mvied for quickly creating Plugins and Themes with WordPress.

### Tutorial
You can find an example plugin using this library at https://github.com/Mvied/example-plugin